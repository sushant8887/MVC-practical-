# MVC-practical-
CURD operation on Employee data
